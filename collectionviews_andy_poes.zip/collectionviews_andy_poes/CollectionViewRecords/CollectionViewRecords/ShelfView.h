//
//  ShelfView.h
//  IntroducingCollectionViews
//
//  Created by Mark Pospesel on 10/9/12.
//  Copyright (c) 2012 Mark Pospesel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShelfView : UICollectionReusableView

+ (NSString *)kind;

@end
